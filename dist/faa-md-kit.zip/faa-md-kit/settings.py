"""Per-installation settings. Edit this file, not the scripts."""
from pathlib import Path

ROOT = Path(__file__).parent

# Where things live.
CHECKLIST = ROOT / "curated" / "downloads.md"  # links to download, with [ ]/[x]/[!] boxes
CURATED = ROOT / "curated"                     # status, references, broken links, skip lists
INBOX = ROOT / "inbox"                         # new downloads go here
ARCHIVE = ROOT / "archive"                     # originals, after conversion
OUTPUT = ROOT / "output" / "md"                # converted .md files

# references.py only tracks links whose host ends with one of these.
TRACK_HOSTS = ("faa.gov", "sharepoint.com")

# Hosts this machine can't reach; links to them are reported as "other network".
OTHER_NETWORK_HOSTS = ()

# How you save web pages: "bookmarklet" (one click; needs javascript: bookmarks allowed)
# or "save-as" (Ctrl+S -> Webpage, Complete; works where bookmarklets are blocked).
# Only changes the hint shown by next_batch.py.
SAVE_PAGE_METHOD = "save-as"
