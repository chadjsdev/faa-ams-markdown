# Download checklist

Download each link into `inbox/` (keep the original filename), then run convert.py.
Web pages: open, then click the save-page bookmarklet. status.py ticks the boxes:
[x] converted, [!] broken (see broken_links.txt), [ ] still to download.

## Start here

- [ ] [Systems Engineering Portal: Policy and Guidance](https://sep.faa.gov/policy_and_guidance/main)
- [ ] [Systems Engineering Portal: home](https://sep.faa.gov/)

## FAA-network links cited by public FAST/faa.gov documents (as of 2026-10-27)

### sep.faa.gov

- [ ] [Systems Engineering Manual](https://sep.faa.gov/file/get/2974)
- [ ] [Enterprise Architecture Products & Amendments](https://sep.faa.gov/file/get/3286)
- [ ] [NAS Segment Implementation Plan (NSIP) portfolio (FAA only)](https://sep.faa.gov/portfolio/main)
- [ ] [NAS Enterprise Architecture Products & Amendments](https://sep.faa.gov/products/architecture)
- [ ] [Infrastructure](https://sep.faa.gov/products/ir/main)
- [ ] [Service](https://sep.faa.gov/products/sr/main)
- [ ] [FAA Services Hierarchy](https://sep.faa.gov/uploads/resources/FAA%20Services%20Hierarchy_20220218.pdf)

### employees.faa.gov

- [ ] [https://employees.faa.gov/documentLibrary/media/Order/FAA_Order_1600.84_Final.pdf](https://employees.faa.gov/documentLibrary/media/Order/FAA_Order_1600.84_Final.pdf)
- [ ] [JO 6000.53D, Remote Maintenance Monitoring Interface Development and Implementation](https://employees.faa.gov/documentLibrary/media/Order/JO_6000_53D.pdf)
- [ ] [ATO Information Systems Security (ISS) Procedures and Guidance](https://employees.faa.gov/org/linebusiness/ato/operations/technical_operations/neo/issp/authorization/)
- [ ] [Information Systems Security Authorization Handbook](https://employees.faa.gov/org/linebusiness/ato/operations/technical_operations/neo/issp/authorization/media/FY19_FAA_Security_Authorization_Handbook.pdf)
- [ ] [Concept Maturity and Technology Development (CMTD)](https://employees.faa.gov/org/staffoffices/ang/development/csg/)
- [ ] [CMTD Guidelines](https://employees.faa.gov/org/staffoffices/ang/development/csg/media/pdf/CSG%20SOP%20%2803-28-2013%29.pdf)
- [ ] [https://employees.faa.gov/tools_resources/budget_finance/](https://employees.faa.gov/tools_resources/budget_finance/)
- [ ] [https://employees.faa.gov/tools_resources/orders_notices/*](https://employees.faa.gov/tools_resources/orders_notices/*)
- [ ] [https://employees.faa.gov/tools_resources/orders_notices/?fuseAction=c.dspDocumentList](https://employees.faa.gov/tools_resources/orders_notices/?fuseAction=c.dspDocumentList)
- [ ] [https://employees.faa.gov/tools_resources/orders_notices/index.cfm](https://employees.faa.gov/tools_resources/orders_notices/index.cfm)
- [ ] [FAA Order 1050.10D, Prevention, Control, and Abatement of FAA Environmental Pollution](https://employees.faa.gov/tools_resources/orders_notices/index.cfm/go/document.information/documentID/1028586)

### ksn2.faa.gov

- [ ] [TRB/ARB Briefing Template](https://ksn2.faa.gov/afn/IT/ADE/EA/ARB/Other%20ARB%20Documents/ARB%20Investment%20Decision%20Briefing%20Template.ppt)
- [ ] [PIR Guidance](https://ksn2.faa.gov/afn/jrcportal/PIRData/Post-Implementation%20Review%20Guidance.pdf)
- [ ] [Approved ACAT Designations by Program Name (FAA only)](https://ksn2.faa.gov/afn/jrcportal/Shared%20Documents/JRC%20Approved%20ACATs.pdf)
- [ ] [JRC Readiness Checklist](https://ksn2.faa.gov/afn/jrcportal/Shared%20Documents/JRC%20Readiness%20Criteria%20Checklist.pdf)
- [ ] [Point of Contact list)](https://ksn2.faa.gov/afn/jrcportal/Shared%20Documents/Stakeholder%20Contact%20Info.pdf)
- [ ] [JRC Readiness Checklist & Decision Planning (FAA only)](https://ksn2.faa.gov/afn/jrcportal/SitePages/CRDR.aspx)
- [ ] [FAA Earned Value Management Website (FAA only)](https://ksn2.faa.gov/afn/jrcportal/SitePages/EVM.aspx)
- [ ] [JRC Readiness Checklist & Decision Planning (FAA only)](https://ksn2.faa.gov/afn/jrcportal/SitePages/FID.aspx)
- [ ] [JRC Processes](https://ksn2.faa.gov/afn/jrcportal/SitePages/Home.aspx)
- [ ] [JRC Readiness Checklist & Decision Planning (FAA only)](https://ksn2.faa.gov/afn/jrcportal/SitePages/IARD.aspx)
- [ ] [JRC readiness checklist](https://ksn2.faa.gov/afn/jrcportal/SitePages/IID.aspx)
- [ ] [Post-Implementation Review Website (FAA only)](https://ksn2.faa.gov/afn/jrcportal/SitePages/PIR.aspx)
- [ ] [Acquisition Practices Toolkit (Concept & Requirements Definition) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/AMSLC.aspx)
- [ ] [Acquisition Practices Toolkit (Contractor Management) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_KM.aspx)
- [ ] [Acquisition Practices Toolkit (Measurement & Analysis) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_MA.aspx)
- [ ] [Acquisition Practices Toolkit (Program Management) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_PM.aspx)
- [ ] [Acquisition Practices Toolkit (Quality Assurance) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_QA.aspx)
- [ ] [Acquisition Practices Toolkit (Requirements Management) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_REQ.aspx)
- [ ] [Acquisition Practices Toolkit (Risk Management) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_RM.aspx)
- [ ] [Acquisition Practices Toolkit (V&V for Practitioners) (FAA only)](https://ksn2.faa.gov/faa/AcquisitionProfessions/Practices/Pages/Disc_VV.aspx)
- [ ] [Integrated Logistics Support KSN Site (FAA only)](https://ksn2.faa.gov/faa/ILSupport/Pages/Default.aspx)
- [ ] [Enterprise Architecture (FAA only)](https://ksn2.faa.gov/faa/ea/SitePages/Home.aspx)
- [ ] [CRD Plan Template](https://ksn2.faa.gov/nextgen/SysEng/NASEAandRqmts/ISE/ANGB13%20Library/CRD%20Plan%20Template%20v4_updated%20_2017_07_11.doc)
- [ ] [Solution ConOps Guidelines and Template](https://ksn2.faa.gov/nextgen/SysEng/NASEAandRqmts/ISE/ANGB13%20Library/ConOps%20Template_Coordination_v%201.0.docx)
- [ ] [Handbook for Writing Requirements](https://ksn2.faa.gov/nextgen/SysEng/NASEAandRqmts/ISE/ANGB13%20Library/Handbook%20for%20Writing%20Program%20Requirements.pdf)
- [ ] [FAA-G-2100 H, Electronic Equipment, General Requirements](https://ksn2.faa.gov/nextgen/SysEng/NASEAandRqmts/ISE/SiteAssets/Attachment_6_FAA-G-2100H.pdf)
- [ ] [ANG-B11 Requirements and Analysis Branch](https://ksn2.faa.gov/nextgen/SysEng/NASEAandRqmts/RA/SitePages/Home.aspx)
- [ ] [ANG-B3 Safety Website](https://ksn2.faa.gov/nextgen/SysEng/SafetyandISS/default.aspx)
- [ ] [NAS Enterprise Safety Handbook](https://ksn2.faa.gov/nextgen/SysEng/SafetyandISS/team/Shared%20Documents/Enterprise%20Safety/SMS%20Policy%20and%20Guidance/NAS%20Enterprise%20Safety%20Handbook/NESH_20190930_NAS%20Enterprise%20Safety%20Handbook%20v1.0_FINAL_508.pdf)
- [ ] [IOA Designation Memo (FAA only)](https://ksn2.faa.gov/stt/sa/PP/AAG)

### my.faa.gov

- [ ] [In-Service Review (ISR) checklist](https://my.faa.gov/content/dam/myfaa/org/linebusiness/ato/safety/isd/documents/ISR-Checklist.doc)
- [ ] [Safety Management System Manual (FAA only)](https://my.faa.gov/content/dam/myfaa/org/linebusiness/ato/safety/sms/documents/ATO-SMS-Manual/202212-SMS-Manual.pdf)
- [ ] [Guide for Conducting Business Case Cost Evaluations](https://my.faa.gov/content/dam/myfaa/org/staffoffices/afn/finance/organization/ipa/guide_to_conducting_business_case_cost_and_schedule_evaluations.pdf)
- [ ] [EA Program Manager Guidance](https://my.faa.gov/content/dam/myfaa/org/staffoffices/afn/information/processes/ade/AIT-ASP-004-W2-Non-NAS-EA-PM-Guidance.pdf)
- [ ] [Investment Nomenclature Framework (FAA only)](https://my.faa.gov/content/dam/myfaa/org/staffoffices/ang/directorates/engineering/Investment%20Nomenclature%20Framework_v1%200%20Final-508.pdf)
- [ ] [Configuration Management Website (FAA only)](https://my.faa.gov/go/closing-the-loop)
- [ ] [EOSH Services Group (FAA only)](https://my.faa.gov/org/linebusiness/ato/operations/facilities_engineering/eosh_services.html)
- [ ] [ISS Assessment templates (ATO) (FAA only)](https://my.faa.gov/org/linebusiness/ato/operations/naseo/ATO_Cybersecurity_Group/issp/ato_ams_iss_templates.html)
- [ ] [https://my.faa.gov/org/linebusiness/ato/operations/naseo/ATO_Cybersecurity_Group/issp/iss_review.html*](https://my.faa.gov/org/linebusiness/ato/operations/naseo/ATO_Cybersecurity_Group/issp/iss_review.html*)
- [ ] [IOA Readiness Declaration & Memo Templates (FAA only)](https://my.faa.gov/org/linebusiness/ato/safety/ioa.html)
- [ ] [ISD Briefing Template (FAA only)](https://my.faa.gov/org/linebusiness/ato/safety/isd.html)
- [ ] [In-Service Review Checklist (FAA only)](https://my.faa.gov/org/linebusiness/ato/safety/isd.html/)
- [ ] [Safety Risk Management Guidance for System Acquisitions (SRMGSA)](https://my.faa.gov/org/linebusiness/ato/safety/sms/documents/SRMGSA.html)
- [ ] [Safety Risk Management Guidance for System Acquisitions (FAA only)](https://my.faa.gov/org/linebusiness/ato/safety/sms/policy/SRMGSA.html)
- [ ] [System Safety Tracking System (FAA only)](https://my.faa.gov/org/linebusiness/ato/safety/sms/smts.html)
- [ ] [Acquisition Quality Assurance (FAA only)](https://my.faa.gov/org/staffoffices/afn/acq_business/acquisition_policy/acquisition_quality_assurance.html)
- [ ] [JRC Readiness Checklist](https://my.faa.gov/org/staffoffices/afn/acq_business/investment_process/jrc.html)
- [ ] [Investment Planning & Analysis Website (FAA only)](https://my.faa.gov/org/staffoffices/afn/finance/organization/investment.html)
- [ ] [Guide to Conducting Business Case Cost Evaluations](https://my.faa.gov/org/staffoffices/afn/finance/organization/investment/ipa_cat.html)
- [ ] [Corporate Work Plan (CWP)](https://my.faa.gov/org/staffoffices/afn/finance/training/cwp/cwp_welcome.html)
- [ ] [System Hazard Analysis](https://my.faa.gov/sites/default/files/org/linebusiness/ato/safety/sms/documents/SRMGSA/SRMGSA.pdf)

### nas.amc.faa.gov

- [ ] [https://nas.amc.faa.gov/phoenix/views/technicalLibrary.xhtml](https://nas.amc.faa.gov/phoenix/views/technicalLibrary.xhtml)

### nasea.faa.gov

- [ ] [TV-1](https://nasea.faa.gov/file/get/2658)
